import React from 'react';

const Logout = (component) => {
	return component;
};

export default Logout;
